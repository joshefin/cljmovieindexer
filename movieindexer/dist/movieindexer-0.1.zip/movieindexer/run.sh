#!/bin/bash

java -jar movieindexer-standalone.jar $@
